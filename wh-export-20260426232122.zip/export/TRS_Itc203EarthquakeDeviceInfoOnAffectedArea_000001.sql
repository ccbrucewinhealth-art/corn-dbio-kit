INSERT INTO [TRS_Itc203EarthquakeDeviceInfoOnAffectedArea] ([SnID], [TRC_M_ID], [AffectedArea_StartStation], [AffectedArea_EndStation], [DH_BATCH_ID])
VALUES
    (NULL, '3', '臺北', '鶯歌（包括樹林調車場）', NULL),
    (NULL, '4', '臺北', '鶯歌（包括樹林調車場）', NULL),
    (NULL, '5', '臺北', '鶯歌（包括樹林調車場）', NULL),
    (NULL, '6', '臺北', '鶯歌（包括樹林調車場）', NULL),
    (NULL, '8', '臺北', '鶯歌（包括樹林調車場）', NULL),
    (NULL, '7', '臺北', '鶯歌（包括樹林調車場）', NULL),
    (NULL, '9', '臺北', '鶯歌（包括樹林調車場）', NULL),
    (NULL, '10', '臺北', '鶯歌（包括樹林調車場）', NULL);
