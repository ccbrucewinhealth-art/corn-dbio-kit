INSERT INTO [RouteOperationStatusOnNetworkList] ([SnID], [TRC_M_ID], [NetworkID], [NetworkName])
VALUES
    ('1', '20260312', NULL, '南區路網'),
    ('2', '20260312', NULL, '南區路網'),
    ('3', '20260312', NULL, '南區路網'),
    ('4', '5', NULL, NULL);
