INSERT INTO [V_Ap213EarthquakeAlert] ([DataTime], [Intensity], [StationName], [StationID])
VALUES
    ('2020-08-27 6:16:07', '1', NULL, NULL),
    ('2020-08-27 6:16:07', '1', NULL, NULL),
    ('2020-08-27 6:16:07', '1', NULL, NULL),
    ('2020-08-27 6:16:07', '1', NULL, NULL),
    ('2020-08-27 6:16:07', '1', NULL, NULL),
    ('2020-08-27 6:16:07', '1', NULL, NULL),
    ('2020-08-27 6:16:07', '1', NULL, NULL),
    ('2020-08-27 6:16:07', '1', NULL, NULL),
    ('2020-08-27 6:16:07', '1', NULL, NULL),
    ('2020-08-27 6:16:07', '1', NULL, NULL);
