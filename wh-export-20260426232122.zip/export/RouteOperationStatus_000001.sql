INSERT INTO [RouteOperationStatus] ([SnID], [AlertID], [Title], [Description], [Status], [Direction], [Level], [Cause], [Effect], [Reason], [AlertURL], [StartTime], [EndTime], [PublishTime], [UpdateTime])
VALUES
    ('5', '1', '測試營運事件', '內灣線營運測試', 'Active', 'Both', 'Info', '測試原因', '測試影響', '系統測試', 'https://test.trc', 'Mar 13 2026  8:37AM', 'Mar 13 2026  9:37AM', 'Mar 13 2026  8:37AM', 'Mar 13 2026  8:37AM');
