INSERT INTO [TRM_SendDelayReasonInfo] ([Dynamic_id], [SendDelayReasonInfo_id], [Date], [TrainCode], [StatNo], [StatName], [DelayReason], [StationSequence], [DH_BATCH_ID])
VALUES
    ('284C6E90-FBB2-4C93-B7CB-1875E83E5D45', '1BCC85B5-4A98-4FEF-92D8-13F7308CD87B', '2026-03-09', 'T001', '1000', '測試站', '設備故障', '1', NULL);
