INSERT INTO [V_Ap210CmtLevelCrossing] ([Placeholder])
VALUES
    (NULL);
