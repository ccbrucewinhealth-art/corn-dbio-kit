INSERT INTO [TRM_Itc101TidsStatus] ([SnID], [ReceiverUnit], [TransmitUnit], [LineNetwork], [DataType], [CdmidL1], [CdmidL2], [CdmidL3], [CdmidL4], [SruidL1], [SruidL2], [SruidL3], [SruidL4], [CreateTime], [UpdateInterval], [Version], [SequenceNo], [SYSCode], [EquipmentCode], [EquipmentStatus], [DH_BATCH_ID])
VALUES
    ('1', 'TRA', 'TRA', 'WL,EL', 'Dynamic', 'SEM', 'TSM', 'TID', 'IIB', 'SEM', 'TSM', '0920', '09207301', '1971-04-18 00:30:00.013 +00:00', '-1.0', 'V1.0', '1', '101', '7301', 'Operational', '6065d2e5-c270-4f51-8618-bb2184074846');
