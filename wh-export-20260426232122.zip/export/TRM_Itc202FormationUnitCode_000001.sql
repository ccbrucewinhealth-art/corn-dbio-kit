INSERT INTO [TRM_Itc202FormationUnitCode] ([SnID], [ReceiverUnit], [TransmitUnit], [LineNetwork], [DataType], [CdmidL1], [CdmidL2], [CdmidL3], [CdmidL4], [SruidL1], [SruidL2], [SruidL3], [SruidL4], [CreateTime], [UpdateInterval], [UploadTime], [Description], [Version], [SYSCode], [DH_BATCH_ID])
VALUES
    ('1', 'TRA', 'TRA', 'N/A', 'Static', 'OPR', 'TON', 'BMA', 'ASU', 'OPR', 'TON', 'BMA', 'ASU-20251124', '1971-11-24 13:46:33.000 +08:00', '-1.0', '2025-11-24 13:46:33.000 +08:00', '編組單位代碼', '1.1', '202', 'fb9bc958-bac7-4fd5-8ce9-4b12ad5afa65'),
    ('2', 'TRA', 'TRA', 'N/A', 'Static', 'OPR', 'TON', 'BMA', 'ASU', 'OPR', 'TON', 'BMA', 'ASU-20251124', '1971-11-24 13:46:33.000 +08:00', '-1.0', '2025-11-24 13:46:33.000 +08:00', '編組單位代碼', '1.1', '202', '20faf5aa-3a86-4ec3-9f2d-17ed7c44e9e7');
