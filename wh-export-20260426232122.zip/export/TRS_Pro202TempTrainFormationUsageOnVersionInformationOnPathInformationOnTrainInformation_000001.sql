INSERT INTO [TRS_Pro202TempTrainFormationUsageOnVersionInformationOnPathInformationOnTrainInformation] ([SnID], [TRC_M_ID], [EndStationCode], [IntervalKM], [TrainCode], [TrainCodeTail], [BeginStationCode], [LeTime], [ArTime], [CrossDay], [Sort], [CodeDate], [SourceTrainCode], [SourceDate], [SwitchDate], [SwitchTrainCode], [DH_BATCH_ID])
VALUES
    ('1', '1', '1715', '185.1', '6046', 'X', '1006', '10:32:00', '13:41:00', '0', '2', '2025-12-25', '7035', '2025-12-24', NULL, NULL, NULL),
    ('2', '1', '4102', '208.95', '6047', 'X', '1715', '16:34:00', '20:25:00', '0', '3', '2025-12-25', NULL, NULL, '2025-12-25', '7036', NULL),
    ('3', '1', '5902', '429.5', '6015', 'X', '1003', '06:13:00', '14:14:00', '0', '2', '2025-12-27', NULL, NULL, NULL, NULL, NULL),
    ('4', '1', '1003', '429.5', '6018', 'X', '5902', '12:46:00', '21:06:00', '1', '3', '2025-12-29', NULL, NULL, NULL, NULL, NULL),
    ('5', '1', '1025', '104.3', '6306', 'X', '1120', '08:00:00', '10:30:00', '0', '2', '2026-01-20', NULL, NULL, NULL, NULL, NULL),
    ('6', '1', '1120', '109', '6307', 'X', '1025', '11:30:00', '14:30:00', '0', '3', '2026-01-20', NULL, NULL, NULL, NULL, NULL),
    ('7', '1', '1319', '17.8', '6308', 'X', '1120', '15:30:00', '16:18:00', '0', '4', '2026-01-20', NULL, NULL, NULL, NULL, NULL),
    ('8', '1', '1120', '17.8', '6308', 'B', '1319', '16:08:00', '16:58:00', '0', '5', '2026-01-20', NULL, NULL, NULL, NULL, NULL),
    ('9', '1', '1107', '145.9', '6305', 'X', '1003', '07:06:00', '09:45:00', '0', '2', '2025-12-28', NULL, NULL, NULL, NULL, NULL),
    ('10', '1', '1003', '145.9', '6305', 'B', '1107', '10:05:00', '12:46:00', '0', '3', '2025-12-28', NULL, NULL, NULL, NULL, NULL);
