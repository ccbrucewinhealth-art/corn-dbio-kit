INSERT INTO [V_Ap210Ctc3System] ([Placeholder])
VALUES
    (NULL);
