INSERT INTO [TRS_Itc202FormationStationCodeOnRootArray] ([SnID], [TRC_M_ID], [StationCode], [StationName], [DH_BATCH_ID])
VALUES
    ('1', '1', '1001', '基隆', NULL),
    ('2', '2', '1001', '基隆', NULL);
