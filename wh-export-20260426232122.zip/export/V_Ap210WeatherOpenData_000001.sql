INSERT INTO [V_Ap210WeatherOpenData] ([Placeholder])
VALUES
    (NULL);
