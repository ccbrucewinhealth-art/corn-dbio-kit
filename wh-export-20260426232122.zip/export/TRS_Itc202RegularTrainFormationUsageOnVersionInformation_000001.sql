INSERT INTO [TRS_Itc202RegularTrainFormationUsageOnVersionInformation] ([SnID], [TRC_M_ID], [FileSeq], [SystemCode], [SysDescription], [VerID], [VersionDesc], [ActiveDateEffectiveDate], [DH_BATCH_ID])
VALUES
    ('1', '1', '1', 'TRA_SYS_202', '定期客車編組運用', '1', 'V1.0', '2025-10-15', NULL),
    ('2', '2', '1', 'TRA_SYS_202', '定期客車編組運用', '1', 'V1.0', '2025-10-15', NULL);
