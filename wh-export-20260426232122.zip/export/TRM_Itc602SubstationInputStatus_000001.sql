INSERT INTO [TRM_Itc602SubstationInputStatus] ([SnID], [ReceiverUnit], [TransmitUnit], [LineNetwork], [DataType], [CdmidL1], [CdmidL2], [CdmidL3], [SruidL1], [SruidL2], [SruidL3], [CreateTime], [UpdateInterval], [Version], [SequenceNo], [SYSCode], [SubstationId], [Status], [DH_BATCH_ID])
VALUES
    ('1', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-01', '2025-02-02 16:01:35.915 +00:00', '-1.0', '1.1', '1', '602', 'S001-01', '正常', 'b6f9cd60-e620-47b8-bbf7-801a6722f83b'),
    ('2', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-01', '2025-02-03 16:01:35.915 +00:00', '-1.0', '1.1', '2', '602', 'S001-01', '正常', 'b6f9cd60-e620-47b8-bbf7-801a6722f83b'),
    ('3', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-01', '2025-02-04 16:01:35.915 +00:00', '-1.0', '1.1', '3', '602', 'S001-01', '正常', 'b6f9cd60-e620-47b8-bbf7-801a6722f83b'),
    ('4', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-01', '2025-02-05 16:01:35.915 +00:00', '-1.0', '1.1', '4', '602', 'S001-01', '正常', 'b6f9cd60-e620-47b8-bbf7-801a6722f83b'),
    ('5', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-01', '2025-02-06 16:01:35.915 +00:00', '-1.0', '1.1', '5', '602', 'S001-01', '正常', 'b6f9cd60-e620-47b8-bbf7-801a6722f83b'),
    ('6', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-01', '2025-02-07 16:01:35.915 +00:00', '-1.0', '1.1', '6', '602', 'S001-01', '正常', 'b6f9cd60-e620-47b8-bbf7-801a6722f83b'),
    ('7', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-01', '2025-02-08 16:01:35.915 +00:00', '-1.0', '1.1', '7', '602', 'S001-01', '正常', 'b6f9cd60-e620-47b8-bbf7-801a6722f83b'),
    ('8', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-01', '2025-02-09 16:01:35.915 +00:00', '-1.0', '1.1', '8', '602', 'S001-01', '正常', 'b6f9cd60-e620-47b8-bbf7-801a6722f83b'),
    ('9', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-01', '2025-02-10 16:01:35.915 +00:00', '-1.0', '1.1', '9', '602', 'S001-01', '正常', 'b6f9cd60-e620-47b8-bbf7-801a6722f83b'),
    ('10', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-01', '2025-02-11 16:01:35.915 +00:00', '-1.0', '1.1', '10', '602', 'S001-01', '正常', 'b6f9cd60-e620-47b8-bbf7-801a6722f83b');
