INSERT INTO [TRM_Pro202TempTrainFormationUsage] ([SnID], [ReceiverUnit], [TransmitUnit], [LineNetwork], [DataType], [CdmidL1], [CdmidL2], [CdmidL3], [CdmidL4], [SruidL1], [SruidL2], [SruidL3], [SruidL4], [CreateTime], [UpdateInterval], [UploadTime], [Description], [Version], [SYSCode], [DH_BATCH_ID])
VALUES
    ('1', 'TRA', 'TRA', 'N/A', 'Static', 'OPR', 'TON', 'BMA', 'TBA', 'OPR', 'TON', 'BMA', '4', '2025-11-24T13:46:28.250+08:00', '-1', '2025-11-24T13:46:28.250+08:00', '臨時客車編組運用', '1.1', '202', '00db5b2b-0b72-4d9e-9e1f-69799cbc5479');
