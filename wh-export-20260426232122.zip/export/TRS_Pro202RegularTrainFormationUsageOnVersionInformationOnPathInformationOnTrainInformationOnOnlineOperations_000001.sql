INSERT INTO [TRS_Pro202RegularTrainFormationUsageOnVersionInformationOnPathInformationOnTrainInformationOnOnlineOperations] ([SnID], [TRC_M_ID], [OprSymName], [ScheduleDay], [DH_BATCH_ID])
VALUES
    ('1', '5', '線上作業', '1111111', NULL);
