INSERT INTO [TRS_Itc202RegularTrainFormationUsageOnVersionInformationOnPathInformationOnTrainInformationOnOnlineOperations] ([SnID], [TRC_M_ID], [OprSymName], [ScheduleDay], [DH_BATCH_ID])
VALUES
    ('1', '1', '線上作業', '1111111', NULL),
    ('2', '2', '線上作業', '1111111', NULL);
