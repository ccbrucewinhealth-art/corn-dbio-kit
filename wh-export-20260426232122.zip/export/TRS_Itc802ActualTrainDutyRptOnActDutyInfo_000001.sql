INSERT INTO [TRS_Itc802ActualTrainDutyRptOnActDutyInfo] ([SnID], [Id], [TRC_M_ID], [Name], [ActTime], [ActDutyTime], [ActCrewKM], [ActRestTime], [ActAddWorkH], [DH_BATCH_ID])
VALUES
    ('1', NULL, '30', NULL, '02:00', '04:38', '370', '07:30', '01:00', NULL),
    ('2', NULL, '30', NULL, '03:00', '05:39', '375', '08:31', '02:00', NULL),
    ('3', NULL, '30', NULL, '04:00', '06:40', '380', '09:32', '03:00', NULL),
    ('4', NULL, '30', NULL, '05:00', '07:41', '385', '10:33', '01:00', NULL),
    ('5', NULL, '30', NULL, '06:00', '08:42', '390', '11:34', '02:00', NULL),
    ('6', NULL, '30', NULL, '07:00', '09:43', '395', '12:35', '03:00', NULL),
    ('7', NULL, '30', NULL, '08:00', '10:44', '400', '13:36', '01:00', NULL),
    ('8', NULL, '30', NULL, '09:00', '11:45', '405', '14:37', '02:00', NULL),
    ('9', NULL, '30', NULL, '10:00', '12:46', '410', '15:38', '03:00', NULL),
    ('10', NULL, '30', NULL, '11:00', '13:47', '415', '16:39', '01:00', NULL);
