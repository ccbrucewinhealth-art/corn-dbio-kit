INSERT INTO [TRS_Pro202TempTrainFormationUsageOnVersionInformation] ([SnID], [TRC_M_ID], [FileSeq], [SystemCode], [SysDescription], [VerID], [VersionDesc], [ActiveDateEffectiveDate], [DH_BATCH_ID])
VALUES
    ('1', '1', '1-5', 'RSATD', '臨時客車編組運用', '7', '114年12月23日臨時客車編組運用表', '2025-12-23', NULL);
