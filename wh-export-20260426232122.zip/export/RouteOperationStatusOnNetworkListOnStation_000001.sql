INSERT INTO [RouteOperationStatusOnNetworkListOnStation] ([SnID], [TRC_M_ID], [StationId], [StationName])
VALUES
    ('1', '20260312', '1213', '新左營'),
    ('2', '20260312', '1213', '新左營'),
    ('3', '20260312', '1213', '新左營'),
    ('4', '5', '1190', '北新竹');
