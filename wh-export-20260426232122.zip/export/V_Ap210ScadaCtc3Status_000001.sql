INSERT INTO [V_Ap210ScadaCtc3Status] ([Placeholder])
VALUES
    (NULL);
