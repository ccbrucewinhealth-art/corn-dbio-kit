INSERT INTO [TRS_Itc202RegularTrainFormationUsageOnVersionInformationOnPathInformationOnTrainInformation] ([SnID], [TRC_M_ID], [Sort], [BeginStationCode], [LeTime], [ArTime], [CrossDay], [IntervalKM], [TrainCode], [EndStationCode], [RunDrivingDay], [DH_BATCH_ID])
VALUES
    ('1', '1', '1', '1000', '08:00', '18:00', '0', '400.5', '110', '4400', '1111111', NULL),
    ('2', '2', '1', '1000', '08:00', '18:00', '0', '400.5', '110', '4400', '1111111', NULL);
