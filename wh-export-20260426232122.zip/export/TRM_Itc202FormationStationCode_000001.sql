INSERT INTO [TRM_Itc202FormationStationCode] ([SnID], [ReceiverUnit], [TransmitUnit], [LineNetwork], [DataType], [CdmidL1], [CdmidL2], [CdmidL3], [CdmidL4], [SruidL1], [SruidL2], [SruidL3], [SruidL4], [CreateTime], [UpdateInterval], [UploadTime], [Description], [Version], [SYSCode], [DH_BATCH_ID])
VALUES
    ('1', 'TRA', 'TRA', 'N/A', 'Static', 'OPR', 'TON', 'BMA', 'SUD', 'OPR', 'TON', 'BMA', 'SUD-20250626', '1971-06-26 20:41:56.000 +08:00', '-1.0', '2025-06-26 20:41:56.000 +08:00', '車站代碼', '1.1', '202', '06534b83-4b88-49b4-b80a-8607dc21fa6e'),
    ('2', 'TRA', 'TRA', 'N/A', 'Static', 'OPR', 'TON', 'BMA', 'SUD', 'OPR', 'TON', 'BMA', 'SUD-20250626', '1971-06-26 20:41:56.000 +08:00', '-1.0', '2025-06-26 20:41:56.000 +08:00', '車站代碼', '1.1', '202', '98ed366a-7316-411f-8bb3-d90e561c98e6');
