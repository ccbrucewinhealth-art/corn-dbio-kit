INSERT INTO [TRM_Pro614StaCctvDeviceStatus] ([SnID], [ReceiverUnit], [TransmitUnit], [LineNetwork], [DataType], [CdmidL1], [CdmidL2], [CdmidL3], [CdmidL4], [SruidL1], [SruidL2], [SruidL3], [SruidL4], [CreateTime], [UpdateInterval], [Version], [SequenceNo], [SYSCode], [CctvID], [Location], [CctvStatus], [ErrorType], [DH_BATCH_ID])
VALUES
    ('8', 'NCC', 'ITS', 'TRA', 'CCTV', '001', '001', '001', '001', 'SR1', 'SR2', 'SR3', 'SR4', '2026-03-10 08:09:41.191 +00:00', '30.0', '1', '1', 'ITC', 'ITC001', '測試月台', 'Normal', 'None', NULL),
    ('9', 'NCC', 'ITS', 'TRA', 'CCTV', '001', '001', '001', '001', 'SR1', 'SR2', 'SR3', 'SR4', '2026-03-16 09:27:49.091 +00:00', '30.0', '1', '2', 'ITC', 'ITC001', '測試月台', 'Error', 'CameraOffline', NULL),
    ('10', 'NCC', 'ITS', 'TRA', 'CCTV', '001', '001', '001', '001', 'SR1', 'SR2', 'SR3', 'SR4', '2026-03-16 09:29:13.758 +00:00', '30.0', '1', '2', 'ITC', 'ITC001', '測試月台', 'Error', 'CameraOffline', NULL),
    ('11', 'NCC', 'ITS', 'TRA', 'CCTV', '001', '001', '001', '001', 'SR1', 'SR2', 'SR3', 'SR4', '2026-03-17 05:59:49.272 +00:00', '30.0', '1', '2', 'ITC', 'ITC001', '測試月台', 'Error', 'CameraOffline', NULL);
