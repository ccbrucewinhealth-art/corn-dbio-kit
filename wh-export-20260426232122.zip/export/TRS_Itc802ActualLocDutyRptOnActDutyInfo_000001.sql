INSERT INTO [TRS_Itc802ActualLocDutyRptOnActDutyInfo] ([SnID], [Id], [TRC_M_ID], [Name], [ActTime], [ActDutyTime], [ActCrewKM], [ActRestTime], [ActAddWorkH], [DH_BATCH_ID])
VALUES
    ('1', NULL, '30', NULL, '2', '4', '370', '1', '1', NULL),
    ('2', NULL, '30', NULL, '2', '4', '380', '2', '1', NULL),
    ('3', NULL, '30', NULL, '2', '4', '390', '3', '1', NULL),
    ('4', NULL, '30', NULL, '2', '4', '400', '1', '1', NULL),
    ('5', NULL, '30', NULL, '2', '4', '410', '2', '1', NULL),
    ('6', NULL, '30', NULL, '2', '4', '420', '3', '1', NULL),
    ('7', NULL, '30', NULL, '2', '4', '430', '1', '1', NULL),
    ('8', NULL, '30', NULL, '2', '4', '440', '2', '1', NULL),
    ('9', NULL, '30', NULL, '2', '4', '450', '3', '1', NULL),
    ('10', NULL, '30', NULL, '2', '4', '460', '1', '1', NULL);
