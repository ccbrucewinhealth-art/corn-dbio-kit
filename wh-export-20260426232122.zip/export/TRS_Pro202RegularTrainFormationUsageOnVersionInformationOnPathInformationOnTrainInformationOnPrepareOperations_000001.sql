INSERT INTO [TRS_Pro202RegularTrainFormationUsageOnVersionInformationOnPathInformationOnTrainInformationOnPrepareOperations] ([SnID], [TRC_M_ID], [OprSymName], [ScheduleDay], [DH_BATCH_ID])
VALUES
    ('1', '5', '整備', '1111111', NULL);
