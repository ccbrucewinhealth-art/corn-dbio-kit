INSERT INTO [TRM_Itc202TempTrainFormationUsage] ([SnID], [ReceiverUnit], [TransmitUnit], [LineNetwork], [DataType], [CdmidL1], [CdmidL2], [CdmidL3], [CdmidL4], [SruidL1], [SruidL2], [SruidL3], [SruidL4], [CreateTime], [UpdateInterval], [UploadTime], [Description], [Version], [SYSCode], [DH_BATCH_ID])
VALUES
    ('1', 'TRA', 'TRA', 'N/A', 'Static', 'OPR', 'TON', 'BMA', 'TBA', 'OPR', 'TON', 'BMA', '4', '1971-11-24T13:46:28.250+08:00', '-1', '2025-11-24T13:46:28.250+08:00', '臨時客車編組運用', '1.1', '202', '3cdfc8a9-1f47-43c3-b5d1-3b16f93ab9a4'),
    ('2', 'TRA', 'TRA', 'N/A', 'Static', 'OPR', 'TON', 'BMA', 'TBA', 'OPR', 'TON', 'BMA', '4', '1971-11-24T13:46:28.250+08:00', '-1', '2025-11-24T13:46:28.250+08:00', '臨時客車編組運用', '1.1', '202', 'd796b758-d837-40c8-9696-c55ab7f9d9a9');
