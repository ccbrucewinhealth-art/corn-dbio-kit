INSERT INTO [Dynamic] ([Dynamic_id], [ReceiverUnit], [TransmitUnit], [LineNetwork], [DataType], [CDMID], [SRUID], [CreateTime], [UpdateInterval], [Version], [SequenceNo], [Payload], [SYSCode])
VALUES
    ('284C6E90-FBB2-4C93-B7CB-1875E83E5D45', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
