INSERT INTO [RouteOperationStatusOnNetworkListOnLine] ([SnID], [TRC_M_ID], [LineId], [LineName])
VALUES
    ('2', '20260312', 'L01', '縱貫線'),
    ('3', '20260312', 'L01', '縱貫線');
