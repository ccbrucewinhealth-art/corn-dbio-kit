INSERT INTO [TRS_Pro202RegularTrainFormationUsageOnVersionInformationOnPathInformation] ([SnID], [TRC_M_ID], [PathCode], [PathType], [OrgCode], [TrainType], [TrainSetsGroupsNum], [TrainNum], [DH_BATCH_ID])
VALUES
    ('1', '5', 'P001', '1', 'TPE', 'EMU900', '1', '10', NULL);
