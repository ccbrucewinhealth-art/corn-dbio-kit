INSERT INTO [V_Ap210UndergroundTunnelMonitoring] ([Placeholder])
VALUES
    (NULL);
