INSERT INTO [V_Ap210TraBridgeTunnelManagement] ([Placeholder])
VALUES
    (NULL);
