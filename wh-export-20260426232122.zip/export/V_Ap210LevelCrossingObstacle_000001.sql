INSERT INTO [V_Ap210LevelCrossingObstacle] ([Placeholder])
VALUES
    (NULL);
