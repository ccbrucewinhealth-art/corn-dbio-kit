INSERT INTO [TRM_Pro801RemainingTicketInfo] ([SnID], [ReceiverUnit], [TransmitUnit], [LineNetwork], [DataType], [CdmidL1], [CdmidL2], [CdmidL3], [SruidL1], [SruidL2], [SruidL3], [CreateTime], [UpdateInterval], [Version], [SequenceNo], [SYSCode], [DepartureDate], [TrainNo], [OriginStaNo], [OriginStaName], [DestinationStaNo], [DestinationStaName], [RemainingSeats], [DH_BATCH_ID])
VALUES
    ('5', 'NCC', 'ITS', 'TRA', 'Seat', '001', '001', '001', 'SR1', 'SR2', 'SR3', '2026-03-10 08:03:35.622 +00:00', '30.0', '1', '1', 'ITC', '2026-03-01', 'ITC1', '1000', '測試站', '1001', '下一站', '100', NULL);
