INSERT INTO [V_Ap210RouteOperationStatus] ([StartTime], [EndTime], [Description], [UpdateTime], [SnID], [LineCode], [TRC_M_ID], [LocationType], [TrackInfo], [StartingStationID], [StartingStationName], [EndingStationID], [EndingStationName], [EngLineName], [StationCode], [StationName], [EngLineCode])
VALUES
    ('Mar 13 2026  8:37AM', 'Mar 13 2026  9:37AM', '內灣線營運測試', 'Mar 13 2026  8:37AM', '5', NULL, '5', NULL, NULL, '1190', '北新竹', '1208', '內灣', NULL, '1190', '北新竹', NULL);
