INSERT INTO [TRS_Pro202RegularTrainFormationUsageOnVersionInformation] ([SnID], [TRC_M_ID], [FileSeq], [SystemCode], [SysDescription], [VerID], [VersionDesc], [ActiveDateEffectiveDate], [DH_BATCH_ID])
VALUES
    ('1', '5', '1', 'TRA_SYS_202', '定期客車編組運用', '1', 'V1.0', '2025-10-15', NULL);
