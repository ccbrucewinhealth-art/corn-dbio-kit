INSERT INTO [TRM_Pro801DailyStaPassengerCounts] ([SnID], [ReceiverUnit], [TransmitUnit], [LineNetwork], [DataType], [CdmidL1], [CdmidL2], [CdmidL3], [CdmidL4], [SruidL1], [SruidL2], [SruidL3], [SruidL4], [CreateTime], [UpdateInterval], [Version], [SequenceNo], [SYSCode], [StaNo], [StaName], [StatisticsDate], [EntryCount], [ExitCount], [DH_BATCH_ID])
VALUES
    ('3', 'TRA', 'TRA', NULL, 'Dynamic', 'OPR', 'OPI', 'PVI', 'IOV', 'OPR', 'OPI', 'PVI', NULL, NULL, '86400.0', '1.1', '1', '801', '1000', '測試站', '2026-03-10', '1000', '900', NULL);
