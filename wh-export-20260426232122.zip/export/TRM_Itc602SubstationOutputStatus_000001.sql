INSERT INTO [TRM_Itc602SubstationOutputStatus] ([SnID], [ReceiverUnit], [TransmitUnit], [LineNetwork], [DataType], [CdmidL1], [CdmidL2], [CdmidL3], [SruidL1], [SruidL2], [SruidL3], [CreateTime], [UpdateInterval], [Version], [SequenceNo], [SYSCode], [SubstationId], [Status], [DH_BATCH_ID])
VALUES
    ('1', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-02', '2025-02-02 16:01:35.915 +00:00', '-1.0', '1.1', '1', '602', 'S001-02', '正常', 'd4aa942e-2b70-450f-abb3-3876d8f685c9'),
    ('2', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-02', '2025-02-03 16:01:35.915 +00:00', '-1.0', '1.1', '2', '602', 'S001-02', '正常', 'd4aa942e-2b70-450f-abb3-3876d8f685c9'),
    ('3', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-02', '2025-02-04 16:01:35.915 +00:00', '-1.0', '1.1', '3', '602', 'S001-02', '正常', 'd4aa942e-2b70-450f-abb3-3876d8f685c9'),
    ('4', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-02', '2025-02-05 16:01:35.915 +00:00', '-1.0', '1.1', '4', '602', 'S001-02', '正常', 'd4aa942e-2b70-450f-abb3-3876d8f685c9'),
    ('5', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-02', '2025-02-06 16:01:35.915 +00:00', '-1.0', '1.1', '5', '602', 'S001-02', '正常', 'd4aa942e-2b70-450f-abb3-3876d8f685c9'),
    ('6', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-02', '2025-02-07 16:01:35.915 +00:00', '-1.0', '1.1', '6', '602', 'S001-02', '正常', 'd4aa942e-2b70-450f-abb3-3876d8f685c9'),
    ('7', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-02', '2025-02-08 16:01:35.915 +00:00', '-1.0', '1.1', '7', '602', 'S001-02', '正常', 'd4aa942e-2b70-450f-abb3-3876d8f685c9'),
    ('8', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-02', '2025-02-09 16:01:35.915 +00:00', '-1.0', '1.1', '8', '602', 'S001-02', '正常', 'd4aa942e-2b70-450f-abb3-3876d8f685c9'),
    ('9', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-02', '2025-02-10 16:01:35.915 +00:00', '-1.0', '1.1', '9', '602', 'S001-02', '正常', 'd4aa942e-2b70-450f-abb3-3876d8f685c9'),
    ('10', 'TRA', 'TRA', 'EL', 'Static', 'SEM', 'PWS', 'TSS', 'SEM', 'PWS', 'S001-02', '2025-02-11 16:01:35.915 +00:00', '-1.0', '1.1', '10', '602', 'S001-02', '正常', 'd4aa942e-2b70-450f-abb3-3876d8f685c9');
