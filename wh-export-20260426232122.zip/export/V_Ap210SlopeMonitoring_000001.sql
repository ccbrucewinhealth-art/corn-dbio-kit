INSERT INTO [V_Ap210SlopeMonitoring] ([Placeholder])
VALUES
    (NULL);
