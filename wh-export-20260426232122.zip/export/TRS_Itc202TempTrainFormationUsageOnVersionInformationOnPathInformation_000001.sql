INSERT INTO [TRS_Itc202TempTrainFormationUsageOnVersionInformationOnPathInformation] ([SnID], [TRC_M_ID], [PathCode], [PathType], [OrgCode], [TrainType], [TrainSetsGroupsNum], [TrainNum], [PaxLocoModeOperationMode], [DH_BATCH_ID])
VALUES
    ('1', '1', '臨B65', 'T', '16', '商務客車/商務餐車', '1', '7', '客車運行', NULL),
    ('2', '1', '臨B66', 'T', '16', '商務客車', '1', '5', '客車運行', NULL),
    ('3', '1', '臨U92A', 'T', '14', 'EMU500', '1', '4', '機車運行', NULL),
    ('4', '1', '臨Y86A', 'T', '16', 'EMU900', '1', '10', '機車運行', NULL),
    ('5', '2', '臨B65', 'T', '16', '商務客車/商務餐車', '1', '7', '客車運行', NULL),
    ('6', '2', '臨B66', 'T', '16', '商務客車', '1', '5', '客車運行', NULL),
    ('7', '2', '臨U92A', 'T', '14', 'EMU500', '1', '4', '機車運行', NULL),
    ('8', '2', '臨Y86A', 'T', '16', 'EMU900', '1', '10', '機車運行', NULL);
