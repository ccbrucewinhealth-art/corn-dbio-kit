INSERT INTO [RouteOperationStatusOnNetworkListOnLineSection] ([SnID], [TRC_M_ID], [LineID], [StartingStationID], [StartingStationName], [EndingStationID], [EndingStationName], [Description])
VALUES
    ('7', '5', 'NW', '1190', '北新竹', '1208', '內灣', '北新竹至內灣區間測試');
