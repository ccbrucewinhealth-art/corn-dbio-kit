INSERT INTO [TRS_Itc502PantographInspectionOnCarriageInfo] ([SnID], [TRC_M_ID], [CarriageNo], [DH_BATCH_ID])
VALUES
    ('1', '20', '100001', NULL),
    ('2', '20', '101001', NULL),
    ('3', '20', '102001', NULL),
    ('4', '20', '103001', NULL),
    ('5', '20', '104001', NULL),
    ('6', '20', '105001', NULL),
    ('7', '20', '106001', NULL),
    ('8', '20', '107001', NULL),
    ('9', '20', '108001', NULL),
    ('10', '20', '109001', NULL);
