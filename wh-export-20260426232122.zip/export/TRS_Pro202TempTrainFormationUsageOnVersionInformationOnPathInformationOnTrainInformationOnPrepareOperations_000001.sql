INSERT INTO [TRS_Pro202TempTrainFormationUsageOnVersionInformationOnPathInformationOnTrainInformationOnPrepareOperations] ([SnID], [TRC_M_ID], [OprSymName], [ScheduleDay], [DH_BATCH_ID])
VALUES
    ('1', '1', '17', NULL, NULL),
    ('2', '1', '1', NULL, NULL),
    ('3', '1', '16', NULL, NULL),
    ('4', '1', '15', NULL, NULL),
    ('5', '1', '15', NULL, NULL);
