INSERT INTO [TRS_Itc202RegularTrainFormationUsageOnVersionInformationOnPathInformationOnTrainInformationOnPrepareOperations] ([SnID], [TRC_M_ID], [OprSymName], [ScheduleDay], [DH_BATCH_ID])
VALUES
    ('1', '1', '整備', '1111111', NULL),
    ('2', '2', '整備', '1111111', NULL);
